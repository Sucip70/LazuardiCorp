/**
 * Lazuardi No-Code Builder — static site runtime
 */
(function () {
  'use strict';

  /* ── Tabs ─────────────────────────────────────────────── */
  document.querySelectorAll('[data-laz-tabs]').forEach(function (root) {
    const tabs = root.querySelectorAll('[role="tab"]');
    const panel = root.querySelector('[role="tabpanel"]');
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        const id = tab.getAttribute('data-tab-id');
        tabs.forEach(function (t) {
          t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
          t.classList.toggle('laz-tab-active', t === tab);
        });
        if (panel && id) {
          panel.id = 'panel-' + id;
          panel.setAttribute('aria-labelledby', 'tab-' + id);
        }
      });
    });
  });

  /* ── Dismissible alerts ───────────────────────────────── */
  document.querySelectorAll('[data-laz-dismiss]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const alert = btn.closest('[role="alert"]');
      if (alert) alert.remove();
    });
  });

  /* ── Modal close ──────────────────────────────────────── */
  document.querySelectorAll('[data-laz-modal-close]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const backdrop = btn.closest('.laz-modal-backdrop');
      if (backdrop) backdrop.remove();
    });
  });

  /* ── Mobile nav toggle ────────────────────────────────── */
  document.querySelectorAll('[data-laz-nav-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const nav = btn.closest('nav');
      const menu = nav && nav.querySelector('[data-laz-nav-menu]');
      if (menu) menu.classList.toggle('laz-hidden');
    });
  });
})();


(function () {
  const pageMap = {"/":"index.html"};

  function resolveHref(href) {
    if (!href || href.startsWith('#') || href.startsWith('http')) return href;
    const path = href.startsWith('/') ? href : '/' + href;
    return pageMap[path] || href;
  }

  if (typeof LAZ_EVENTS !== 'object' || !LAZ_EVENTS) return;

  document.querySelectorAll('[data-laz-event]').forEach(function (el) {
    const nodeId = el.getAttribute('data-node-id');
    const eventName = el.getAttribute('data-laz-event');
    if (!nodeId || !eventName) return;

    el.addEventListener(eventName, function (e) {
      const cfg = LAZ_EVENTS[nodeId] && LAZ_EVENTS[nodeId][eventName];
      if (!cfg) return;
      if (cfg.preventDefault) e.preventDefault();
      if (cfg.stopPropagation) e.stopPropagation();

      switch (cfg.action) {
        case 'navigate':
          window.location.href = resolveHref(cfg.payload.href || '/');
          break;
        case 'openUrl':
          window.open(cfg.payload.url || cfg.payload.href || '#', cfg.payload.target || '_blank');
          break;
        case 'scrollTo':
          { const target = document.querySelector(cfg.payload.selector || cfg.payload.elementId || '');
            if (target) target.scrollIntoView({ behavior: 'smooth' }); }
          break;
        case 'toggleVisibility':
          { const target = document.querySelector(cfg.payload.selector || '');
            if (target) target.classList.toggle('laz-hidden'); }
          break;
        case 'runScript':
          if (cfg.payload.code) { try { eval(cfg.payload.code); } catch (err) { console.error(err); } }
          break;
        default:
          console.log('Unhandled action', cfg.action, cfg.payload);
      }
    });
  });
})();

